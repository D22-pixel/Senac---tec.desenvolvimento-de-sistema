programa {
	
	funcao inicio() {

		caracter sexo
		inteiro idade
		inteiro qtdLivros

		//Variáveis necessárias para exibição final
		inteiro qtdMenores = 0
		inteiro qtdMulheresLeitoras = 0
		inteiro qtdHomensLeitores = 0
		real mediaIdadeHomensLeitores = 0.0
		real qtdNaoLeitores = 0.0

		faca {
			escreva("\nDigite a idade: ")
			leia(idade)
			
			se (idade == 0) {
				pare
			}
			
			escreva("\nDigite o sexo (M) ou (F): ")
			leia(sexo)
			escreva("\nDigite a quantidade de livros lidas: ")
			leia(qtdLivros)

			se(idade < 10) {
				qtdMenores = qtdMenores + qtdLivros
			}

			se(sexo == 'F' e qtdLivros >= 5){
				qtdMulheresLeitoras++
			}

			se(sexo == 'M' e qtdLivros < 5) {
				qtdHomensLeitores++
				mediaIdadeHomensLeitores = mediaIdadeHomensLeitores/qtdHomensLeitores
			}

			se(qtdLivros == 0) {
				qtdNaoLeitores++
			}
		}enquanto(idade != 0)

		escreva("\nTotal de livros lidos por menores de 10 anos: " + qtdMenores)
		escreva("\nTotal de mulheres que leram 5 livros ou mais: " + qtdMulheresLeitoras)
		escreva("\nMédia de idade de homens que leram menos de 5 livros: " + mediaIdadeHomensLeitores)
		escreva("\nPercentual de pessoas que não leram livros: " + qtdNaoLeitores/100 + "%")
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 293; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = {qtdMenores, 10, 10, 10}-{qtdMulheresLeitoras, 11, 10, 19}-{qtdHomensLeitores, 12, 10, 17};
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */