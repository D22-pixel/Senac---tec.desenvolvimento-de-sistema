programa {
	
	funcao inicio() {

		cadeia nomeFuncionario
		inteiro idadeFuncionario
		real valorHora
		inteiro horasTrabalhadas
		real salarioFuncionario

		inteiro contadorFuncionarios = 0

		/*
		 * As variáveis abaixo servirão como variáveis de controle
		 * Os valores delas serão substituídas conforme o loop acontece
		 * A cada volta do loop ele testará a idade e o salário
		 * Assim que encontrar a condição verdadeira irá substituir as variáveis de controle pelos valores
		 * Tudo isso dentro de SEs! :D
		 */

		 inteiro maiorIdade = 0
		 cadeia nomeFuncionarioMaisVelho = " "
		 cadeia nomeFuncionarioMaiorRenda = " "
		 real funcionarioMaiorRenda = 0.0
		 real mediaSalarial = 0.0

		enquanto(contadorFuncionarios < 3) {
			escreva("\nDigite o nome do Funcionário: ")
			leia(nomeFuncionario)

			escreva("\nDigite a idade de " + nomeFuncionario + ": " )
			leia(idadeFuncionario)

			escreva("\nQual o valor hora de " + nomeFuncionario + ": ")
			leia(valorHora)

			escreva("\nE quantas horas " + nomeFuncionario + " trabalhou? ")
			leia(horasTrabalhadas)

			salarioFuncionario = horasTrabalhadas * valorHora

			//Neste bloco fazemos o teste
			//Se a idade digitada for maior que a idade que está na variável maiorIdade
			//Este será o novo valor da variável e também aproveitamos o teste lógico para substituir o nome!
			se(idadeFuncionario > maiorIdade) {
				nomeFuncionarioMaisVelho = nomeFuncionario
				maiorIdade = idadeFuncionario
			}

			//Aqui seguimos a mesma lógica, porém trocamos as variáveis :)
			se(salarioFuncionario > funcionarioMaiorRenda) {
				funcionarioMaiorRenda = salarioFuncionario
				nomeFuncionarioMaiorRenda = nomeFuncionario				
			}

			//Por fim, incrementamos a variável da media até o loop acabar e o contador!
			mediaSalarial = mediaSalarial + salarioFuncionario

			contadorFuncionarios++
			
			escreva("\n=================================")
		}

		//Agora só mostrar os resultados finais!
		escreva("\nA média salárial da empresa: " + mediaSalarial/contadorFuncionarios)
		escreva("\nO funcionário mais velho é " + nomeFuncionarioMaisVelho + " com " + maiorIdade + " anos de idade")
		escreva("\nO funcionário com a maior renda é " + nomeFuncionarioMaiorRenda + " com renda de R$" + funcionarioMaiorRenda)
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 2069; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = {maiorIdade, 21, 11, 10}-{nomeFuncionarioMaisVelho, 22, 10, 24}-{nomeFuncionarioMaiorRenda, 23, 10, 25}-{funcionarioMaiorRenda, 24, 8, 21}-{mediaSalarial, 25, 8, 13};
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */