programa {
	
	funcao inicio() {

		inteiro multiplicador = 0
		inteiro numero

		escreva("Digite um número para fazermos a tabuada: ")
		leia(numero)

		enquanto(multiplicador < 11) {
			escreva("\n" + numero + " x " + multiplicador + " = " + numero*multiplicador)
			multiplicador++
		}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 205; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */