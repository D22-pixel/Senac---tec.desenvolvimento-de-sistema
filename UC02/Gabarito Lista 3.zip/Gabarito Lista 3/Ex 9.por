programa {
	
	funcao inicio() {

		caracter opcao
		inteiro voto
		/*
		 * A variável lógico aqui fará todo o trabalho de retornar ao primeiro menu
		 * Cada voto que for válido a variável irá mudar para verdadeiro, levando o usuário para o primeiro menu
		 * Se for inválido, o manterá no menu de candidatos, respeitando o laço!
		 */
		logico votou = falso

		//Variáveis para contar os votos
		inteiro homemDeFerro = 0 //Número 1
		inteiro hulk = 0 //Número 2
		inteiro miranha = 0 //Número 3
		inteiro branco = 0 //Número 0
		inteiro nulo = 0 //Número 9

		faca {
			escreva("\n======BEM-VINDO A URNA ELETRÔNICA=======")
			escreva("\n======(V) para Votar====================")
			escreva("\n======(T) para Terminar=================")
			escreva("\n========================================")
			escreva("\nDigite o opção desejada ====> ")
			leia(opcao)

			escolha(opcao) {
				caso 'V':
					faca {
						escreva("\n ESCOLHA SEU CANDIDATO ")
						escreva("\n 1 - Homem de Ferro")
						escreva("\n 2 - Hulk")
						escreva("\n 3 - Homem-Aranha")
						escreva("\n 0 - Branco")
						escreva("\n 9 - Nulo")
						escreva("\n Digite seu voto ====> ")
						leia(voto)

						escolha(voto) {
							caso 1:
								homemDeFerro++
								votou = verdadeiro
								pare
							caso 2:
								hulk++
								votou = verdadeiro
								pare
							caso 3:
								miranha++
								votou = verdadeiro
								pare
							caso 0:
								branco++
								votou = verdadeiro
								pare
							caso 9:
								nulo++
								votou = verdadeiro
								pare
							caso contrario:
								escreva("\nVoto inválido!")
								votou = falso
								pare
						}
					}enquanto(votou == falso)
					pare
				caso 'T':
					escreva("\nObrigado por votar!")
					escreva("\nContando os votos...")
					pare
				caso contrario:
					escreva("\nOpção inválida")
					pare
			}
		}enquanto(opcao != 'T')

		escreva("\n=======Contagem de Votos=======")
		escreva("\nHomem de Ferro ====> " + homemDeFerro)
		escreva("\nHulk ====> " + hulk)
		escreva("\nHomem-Aranha ====> " + miranha)
		escreva("\nBrancos ====> " + branco)
		escreva("\nNulos ====> " + nulo)
		escreva("\n=======Contagem de Votos=======")
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 862; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = {homemDeFerro, 15, 10, 12}-{hulk, 16, 10, 4}-{miranha, 17, 10, 7}-{branco, 18, 10, 6}-{nulo, 19, 10, 4};
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */