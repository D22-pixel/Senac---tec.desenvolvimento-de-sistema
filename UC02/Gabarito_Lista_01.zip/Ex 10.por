programa
{
	
	funcao inicio()
	{
		real publico
		real renda
		real popular
		real geral
		real arquibancada
		real cadeiras
		
		escreva("Informe o público do jogo: ")
		leia(publico)
		
		popular = publico * 0.1
		geral = publico * 0.5
		arquibancada = publico * 0.3
		cadeiras = publico * 0.1

		renda = (popular * 5) + (geral * 10) + (arquibancada * 20) + (cadeiras * 30)

		escreva("O valor da renda total é R$ " + renda)
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 431; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */