programa {
	
	funcao inicio() {

		real salarioFixo
		real valorVendas
		real comissao
		real valorComissao
		real salarioTotal

		escreva("Digite o salário fixo: ")
		leia(salarioFixo)
		escreva("\nDigite o valor das vendas totais: ")
		leia(valorVendas)
		escreva("\nDigite o percentual da comissão: ")
		leia(comissao)

		valorComissao = valorVendas * comissao

		escreva("\nValor da comissão é: " + valorComissao)

		salarioTotal = salarioFixo + valorComissao

		escreva("\nO salário total é: R$" + salarioTotal)
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 521; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */