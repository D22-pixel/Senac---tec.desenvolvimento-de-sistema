programa {
	
	funcao inicio() {

		inteiro raio
		inteiro altura

		inteiro volume

		escreva("Digite o valor do raio: ")
		leia(raio)

		escreva("\nDigite a altura: ")
		leia(altura)

		volume = 3.14 * ((raio * raio) * altura)

		escreva("O volume da lata é: " + volume)
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 276; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */