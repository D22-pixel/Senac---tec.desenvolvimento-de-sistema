programa {
	
	funcao inicio() {

		real tempoViagem
		real velocidade
		real distancia
		real litrosUsados

		escreva("Digite o tempo da viagem: ")
		leia(tempoViagem)
		escreva("\nDigite o a velocidade média: ")
		leia(velocidade)

		distancia = tempoViagem * velocidade

		escreva("\nA distância percorrida foi: " + distancia + "KM")

		litrosUsados = distancia / 12

		escreva("\nLitros usados na viagem: " + litrosUsados + " litros")

		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 442; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */