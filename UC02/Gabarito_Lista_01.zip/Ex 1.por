programa {
	
	funcao inicio() {

		inteiro num1
		inteiro num2
		inteiro soma

		escreva("Digite um valor: ")
		leia(num1)
		escreva("\nDigite outro valor: ")
		leia(num2)

		soma = num1 + num2

		escreva("\nA soma dos dois valores é: " + soma)
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 249; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */