programa {
	
	funcao inicio() {

		inteiro num1
		inteiro num2
		inteiro num3

		real media

		escreva("Digite um valor: ")
		leia(num1)

		escreva("\nDigite um valor: ")
		leia(num2)

		escreva("\nDigite um valor: ")
		leia(num3)

		media = (num1 + num2 + num3) / 3

		escreva("\nA média dos três valores é: " + media)
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 324; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */