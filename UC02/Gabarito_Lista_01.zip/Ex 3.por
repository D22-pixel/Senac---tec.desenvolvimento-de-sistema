programa {
	
	funcao inicio() {

		inteiro idade

		//Criamos as variáveis para poder armazenar os resultados
		inteiro dias
		inteiro horas
		inteiro minutos
		inteiro segundos

		escreva("Digite sua idade: ")
		leia(idade)

		dias = idade*365

		horas = dias*24

		minutos = horas*60

		segundos = minutos*60

		escreva("\nIdade em dias: " + dias + " dias")
		escreva("\nIdade em horas: " + horas + " horas")
		escreva("\nIdade em minutos: " + minutos + " minutos")
		escreva("\nIdade em segundos: " + segundos + " segundos")
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 230; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */