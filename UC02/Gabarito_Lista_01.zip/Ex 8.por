programa {
	
	funcao inicio() {

		real valor
		real taxa
		real tempoEmAtraso
		real prestacao

		escreva("Digite o valor da parcela: ")
		leia(valor)
		escreva("\nDigite o valor da taxa: ")
		leia(taxa)
		escreva("\nDigite o tempo em atraso: ")
		leia(tempoEmAtraso)

		prestacao = valor + (valor * (taxa/100) * tempoEmAtraso)

		escreva("\nValor da prestação é: R$" + prestacao)
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 389; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */