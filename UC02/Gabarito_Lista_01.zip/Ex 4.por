programa {
	
	funcao inicio() {

		inteiro grausF

		real grausC

		escreva("Quantos graus está hoje? ")
		leia(grausF)

		//Como é uma divisão, não esqueça do .0 !
		grausC = (grausF - 32.0) * (5.0/9.0)

		escreva("A temperatura em Celsius é: " + grausC)
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 169; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */