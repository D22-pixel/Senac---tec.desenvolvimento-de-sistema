programa {
	
	funcao inicio() {

		inteiro num

		escreva("Digite um número: ")
		leia(num)

		/*
		Para resolver a lógica desse exercício é super simples
		Precisamos usar o símbolo % para fazermos a comparação entre a variável e o número 2
		1 - % - É símbolo que usamos para pegarmos o resto de uma divisão
		2 - Por isso dividimos por 2, qualquer número que é divisível por 2 e tem seu RESTO em 0 é PAR!
		PS: Poderiamos ter construído isso também de maneira inversa
		se(num % 2 !0) ---> ímpar!
		*/
		se(num % 2 == 0) {
			escreva ("O " + num + " é par!")
		}senao {
			escreva ("O " + num + " é ímpar!")
		}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 619; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */