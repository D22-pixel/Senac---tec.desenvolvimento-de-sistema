programa {
	
	funcao inicio() {

		//Primeiro de tudo devemos ter as variáveis para cada nota
		inteiro nota100
		inteiro nota50
		inteiro nota20
		inteiro nota10
		inteiro nota5
		inteiro nota1

		//Agora precisamos ter o resto, para usar em cada cálculo
		//Importante iniciar as variáveis como ZERO, pois elas serão usadas em cálculos
		//E como não terão entrada de dados dos usuários o programa não funciona nem inicializa-las
		inteiro resto100 = 0
		inteiro resto50 = 0
		inteiro resto20 = 0
		inteiro resto10 = 0
		inteiro resto5 = 0
		inteiro resto1 = 0
		//Essas variáveis servirão para sabermos que o resto não é zero
		//Se não for zero significa que ainda temos que retornar mais notas para o usuário!

		inteiro valorSaque

		escreva("Quanto você deseja sacar? ")
		leia(valorSaque)

		/*
		A estrutura dos SE é um pouco diferente nesse processo
		Podem perceber que não existem SENAO SE ou até mesmo um SENAO
		Porque? Bem simples!
		É preciso que TODOS os SEs sejam testados, já que as variáveis vão diminuindo
		Se usassemos um SENAO SE, ele encontraria o resultado VERDADEIRO e terminaria o programa
		Por isso os SEs estão isolados e não concatenados, para que todos sejam testados
		E principalmente são testados um depois do outro e não só em uma expressão!
		*/
		
		
		se(valorSaque > 100) {
			nota100 = valorSaque / 100
			resto100 = valorSaque % 100
			escreva("\nCédulas de R$ 100: " + nota100)
		}

		se(valorSaque > 50) {
			nota50 = resto100 / 50
			resto50 = resto100 % 50
			escreva("\nCédulas de R$ 50: " + nota50)
		}

		se(valorSaque > 20) {
			nota20 = resto50 / 20
			resto20 = resto50 % 20
			escreva("\nCédulas de R$ 20: " + nota20)
		}

		se(valorSaque > 10) {
			nota10 = resto20 / 10
			resto10 = resto20 % 10
			escreva("\nCédulas de R$ 10: " + nota10)
		}

		se(valorSaque > 5) {
			nota5 = resto10 / 5
			resto5 = resto10 % 5
			escreva("\nCédulas de R$ 5: " + nota5)
		}

		se(valorSaque > 1) {
			nota1 = resto5 / 1
			resto1 = resto5 % 1
			escreva("\nCédulas de R$ 1: " + nota1)
		}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 1283; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */