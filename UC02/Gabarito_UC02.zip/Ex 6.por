programa {
	
	funcao inicio() {

		real altura

		escreva("Digite sua altura: ")
		leia(altura)

		se(altura < 1.60) {
			escreva("Pintor de rodapé!")
		}senao se(altura < 1.85) {
			escreva("É chato ser comum, né?")
		}senao {
			escreva("Faz frio aí em cima?")
		}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 271; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */