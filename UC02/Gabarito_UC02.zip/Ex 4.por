programa {
	
	funcao inicio() {

		real altura
		caracter sexo
		real pesoIdeal

		escreva("Digite o seu sexo (H) ou (M): ")
		leia(sexo)
		escreva("Digite sua altura: ")
		leia(altura)
		//Considere digitar a altura como um número real
		//No caso, ao invés de 180 digite 1.80, assim o cálculo sairá correto

		se(sexo == 'H') {
			pesoIdeal = (72.7 * altura) - 58
		}senao {
			pesoIdeal = (62.1 * altura) - 44.7
		}

		escreva("Seu peso ideal é: " + pesoIdeal)
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 313; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */