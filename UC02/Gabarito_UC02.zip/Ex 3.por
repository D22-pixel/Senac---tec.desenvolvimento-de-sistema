programa {
	
	funcao inicio() {

		inteiro diaDaSemana

		escreva("Que dia da semana é hoje? ")
		leia(diaDaSemana)

		/*
		O segredo aqui neste algoritmo é diminuirmos nosso trabalho nas condicionais
		Pegamos então os dois extremos, nesse caso, 1 e 7 e usamos eles para testar as possibilidades
		Assim chegamos a completar as três possíveis respostas que temos
		Essa técnica é super útil quando trabalhamos com diversas condicionais e pode ser aplicada em diversas situações
		*/
		se(diaDaSemana == 1 ou diaDaSemana == 7) {
			escreva("Final de semana!")
		} senao se(diaDaSemana < 1 ou diaDaSemana > 7) {
			escreva("Dia inválido!")
		} senao {
			escreva("Dia útil!")
		}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 484; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */