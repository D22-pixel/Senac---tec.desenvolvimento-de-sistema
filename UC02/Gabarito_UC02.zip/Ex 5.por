programa {
	
	funcao inicio() {

		inteiro pesoPeixe
		inteiro excesso
		inteiro valorMulta

		escreva("Olá, Inácio, digite o peso dos peixes hoje: ")
		leia(pesoPeixe)

		se(pesoPeixe > 50) {
			excesso = pesoPeixe - 50
			valorMulta = excesso * 4
		}senao {
			excesso = 0
			valorMulta = 0
		}

		escreva("Inácio o excesso de peixes é: " + excesso)
		escreva("\nE você deverá pagar R$ " + valorMulta + " como multa")
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 264; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */