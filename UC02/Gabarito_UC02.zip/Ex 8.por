programa {
	
	funcao inicio() {

		inteiro idade
		inteiro valorConvenio

		escreva("Digite a idade do conveniado: ")
		leia(idade)

		/*
		Aqui usamos os símbolos de comparação para cumprir todas as bases do contexto da atividade
		Começando do primeiro
		idade < 10 - Vamos de 0 a 9 anos
		idade <=30 - Como o primeiro SE deu falso, caímos aqui, vamos de 10 a 30
		idade <=60 - Como o primeiro e segundo SE deu falso, vamos de 31 a 60
		senao - Como todos os SEs anteriores deram falso, vamos de 61 para cima
		*/
		
		se (idade < 10) {
			valorConvenio = 220 + 80
		}senao se (idade <= 30) {
			valorConvenio = 220 + 150
		}senao se (idade <= 60) {
			valorConvenio = 220 + 195
		}senao {
			valorConvenio = 220 + 250
		}

		escreva("O valor a ser pago pelo conveniado é: R$ " + valorConvenio)

		/*
		 * A lógica desse exercício também pode ser invertida
		 * Seguindo da maior idade até a menor!
		*/

		se (idade > 60) {
			valorConvenio = 220 + 250
		}senao se (idade >= 31) {
			valorConvenio = 220 + 195
		}senao se (idade >= 10) {
			valorConvenio = 220 + 150
		}senao {
			valorConvenio = 220 + 80
		}

		escreva("O valor a ser pago pelo conveniado é: R$ " + valorConvenio)
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 729; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */